import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BadgeCheck, Image, Phone } from "lucide-react";

export default function AvadhResidencyWebsite() {
  return (
    <div className="min-h-screen bg-gradient-to-r from-green-100 to-blue-100 p-6">
      <header className="text-center py-10">
        <h1 className="text-5xl font-bold text-green-700">Avadh Residency</h1>
        <p className="text-lg text-gray-600 mt-2">Residential Plots in Jawad, M.P.</p>
        <p className="text-xl text-green-800 mt-4 font-semibold">1000, 1200 & 1500 sq. ft. Vastu-Compliant Plots</p>
        <Button className="mt-6 bg-green-700 hover:bg-green-800 text-white">Book a Site Visit</Button>
      </header>

      <section className="max-w-6xl mx-auto my-12">
        <h2 className="text-3xl font-bold text-green-700 text-center mb-6">Plot Sizes Available</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
          <Card className="shadow-lg">
            <CardContent className="p-6">
              <h3 className="text-2xl font-semibold">1000 sq. ft.</h3>
              <p className="text-gray-600">Perfect for compact and smart living.</p>
            </CardContent>
          </Card>
          <Card className="shadow-lg">
            <CardContent className="p-6">
              <h3 className="text-2xl font-semibold">1200 sq. ft.</h3>
              <p className="text-gray-600">Balanced space for a beautiful home.</p>
            </CardContent>
          </Card>
          <Card className="shadow-lg">
            <CardContent className="p-6">
              <h3 className="text-2xl font-semibold">1500 sq. ft.</h3>
              <p className="text-gray-600">Spacious plots with full comfort.</p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="bg-white py-12">
        <h2 className="text-3xl font-bold text-center text-green-700 mb-8">Amenities</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {["Gated Community with Security", "Wide RCC Roads", "Children's Park & Garden", "Underground Electric Cabling", "Overhead Water Tank", "Ramdarbar Temple", "Community Hall", "Fountains", "Jogging Track", "Street Lights", "Nearby Schools & Market", "Vastu-Compliant Plots"].map((item, idx) => (
            <div key={idx} className="flex items-center p-4 shadow-md rounded-xl bg-green-50">
              <BadgeCheck className="text-green-600 mr-3" />
              <span className="text-gray-800 font-medium">{item}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="py-12 bg-gradient-to-br from-blue-50 to-green-100 text-center">
        <h2 className="text-3xl font-bold text-green-700 mb-6">Gallery</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-6xl mx-auto">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="bg-white p-3 rounded-lg shadow-md">
              <Image className="mx-auto text-green-400" size={80} />
              <p className="mt-2 text-sm text-gray-600">Image {i}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-12 bg-white text-center">
        <h2 className="text-3xl font-bold text-green-700 mb-4">Find Us Here</h2>
        <div className="w-full h-96 max-w-4xl mx-auto">
          <iframe
            title="Avadh Residency Location"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3770.524264118628!2d74.87060751490184!3d24.56801498419364!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjTCsDM0JzA0LjgiTiA3NMKwNTInMTUuNSJF!5e0!3m2!1sen!2sin!4v1616141593135!5m2!1sen!2sin"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
          ></iframe>
        </div>
      </section>

      <section className="py-12 bg-green-50">
        <h2 className="text-3xl font-bold text-center text-green-700 mb-6">Contact Us</h2>
        <div className="max-w-xl mx-auto bg-white p-6 rounded-xl shadow-md">
          <form className="grid grid-cols-1 gap-4">
            <input type="text" placeholder="Full Name" className="p-3 border rounded" />
            <input type="email" placeholder="Email Address" className="p-3 border rounded" />
            <input type="tel" placeholder="Phone Number" className="p-3 border rounded" />
            <textarea placeholder="Your Message" rows="4" className="p-3 border rounded"></textarea>
            <Button className="bg-green-600 hover:bg-green-700 text-white">Send Message</Button>
          </form>
        </div>
      </section>

      <footer className="mt-12 text-center py-6 border-t border-gray-300">
        <p className="text-gray-600">&copy; 2025 Avadh Residency, Jawad. All rights reserved.</p>
        <p className="text-sm text-gray-500 flex justify-center items-center gap-2 mt-2">
          <Phone size={16} /> +91-79871 38295
        </p>
      </footer>
    </div>
  );
}